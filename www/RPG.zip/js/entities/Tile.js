
function Tile() {
	var currentTexture;


	this.changeTexture = function (_which) {
		switch(_which) {
			case 0:
			break;
			case 1:
			break;
		}
	}
}
